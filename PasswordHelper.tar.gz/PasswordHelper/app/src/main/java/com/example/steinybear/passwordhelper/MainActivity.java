package com.example.steinybear.passwordhelper;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    //AssetManager am = this.getApplicationContext().getAssets();
    //InputStream is = getResourceAsStream("cain.txt");
    InputStream file;
    FileInputStream is;
    BufferedReader r;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            file = getAssets().open("cain.txt");
            is = new FileInputStream(String.valueOf(file));
            r = new BufferedReader(new InputStreamReader(is));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Button checkButton = (Button)findViewById(R.id.checkButton);
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    checkPassword();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void checkPassword() throws IOException {
        count = 0;
        String line = null;
        TextView passwordView = (TextView)findViewById(R.id.passwordTextView);
        String password = passwordView.getText().toString().toLowerCase();
        while((line = r.readLine().toLowerCase()) != null) {
            if (line.contains(password)) {
                count++;
                passwordView.setText(String.valueOf(count));
            }
        }

        //file.close();
        r.close();
    }
}
